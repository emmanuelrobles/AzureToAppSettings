self.addEventListener('fetch',() => {})/* Manifest version: 3c1u/aFW */
