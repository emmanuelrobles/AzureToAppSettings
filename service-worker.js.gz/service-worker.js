self.addEventListener('fetch',() => {})/* Manifest version: JAyzAzbd */
