self.addEventListener('fetch',() => {})/* Manifest version: 35AYVR+6 */
