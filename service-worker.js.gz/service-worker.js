self.addEventListener('fetch',() => {})/* Manifest version: cRvktCkA */
