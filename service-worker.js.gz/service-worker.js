self.addEventListener('fetch',() => {})/* Manifest version: CJ2CeqS7 */
