self.addEventListener('fetch',() => {})/* Manifest version: 09+iWzeK */
