self.addEventListener('fetch',() => {})/* Manifest version: CUjSuYV6 */
