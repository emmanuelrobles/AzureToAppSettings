self.addEventListener('fetch',() => {})/* Manifest version: ADXAAZwN */
