self.addEventListener('fetch',() => {})/* Manifest version: WjWBm1YE */
