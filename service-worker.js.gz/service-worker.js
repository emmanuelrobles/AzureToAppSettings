self.addEventListener('fetch',() => {})/* Manifest version: xnnfXEOP */
