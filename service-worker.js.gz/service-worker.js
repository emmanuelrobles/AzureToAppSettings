self.addEventListener('fetch',() => {})/* Manifest version: GzvwRaYa */
