self.addEventListener('fetch',() => {})/* Manifest version: /kfxHkxy */
